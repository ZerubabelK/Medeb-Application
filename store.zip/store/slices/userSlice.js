import {createSlice} from '@reduxjs/toolkit';
import axios from 'axios';
const initialState = {
  user: null,
  isLogged: false,
  verificationPending: false,
};
const baseURL = 'http://192.168.43.70:9000/api/';
const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    async login(state, {payload}) {
      const response = await axios.post(baseURL + 'auth/login', payload, {
        headers: {
          'Content-Type': 'application/json',
        },
      });
      console.log(response);
      state.isLogged = true;
    },
    logout(state) {
      state.isLogged = false;
    },
    async signup(state, {payload}) {
      const response = await axios.post(baseURL + 'auth/signup', payload, {
        headers: {
          'Content-Type': 'application/json',
        },
      });
      if (response.status == 200) {
        state.user = response.data;
        state.verificationPending = true;
        console.log(response.data);
      }
    },
    async verifyUser(state, {payload}) {
      const response = await axios.post(baseURL + `confirmCode/${payload}`);
      console.log(response);
    },
  },
});

export const {login, logout, signup, verifyUser} = userSlice.actions;
export default userSlice.reducer;
