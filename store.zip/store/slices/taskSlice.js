import {createSlice} from '@reduxjs/toolkit';

const initialState = {
  cachedTask: {subtasks: []},
  allTasks: [
    {
      id: Math.random() * 1000,
      tag: 'Progressing',
      task: 'User flow mapping',
      desc: 'Raisen',
      subtasks: [
        {id: Math.random() * 1000, title: 'Something', done: false},
        {id: Math.random() * 1000, title: 'Something', done: true},
        {id: Math.random() * 1000, title: 'Something', done: true},
        {id: Math.random() * 1000, title: 'Something', done: false},
      ],
    },
    {
      id: Math.random() * 1000,
      tag: 'Progressing',
      task: 'User flow mapping',
      desc: 'Raisen',
      subtasks: [
        {id: Math.random() * 1000, title: 'Something', done: false},
        {id: Math.random() * 1000, title: 'Something', done: true},
        {id: Math.random() * 1000, title: 'Something', done: true},
        {id: Math.random() * 1000, title: 'Something', done: false},
      ],
    },
    {
      id: Math.random() * 1000,
      tag: 'Progressing',
      task: 'User flow mapping',
      desc: 'Raisen',
      subtasks: [
        {id: Math.random() * 1000, title: 'Something', done: false},
        {id: Math.random() * 1000, title: 'Something', done: true},
        {id: Math.random() * 1000, title: 'Something', done: true},
        {id: Math.random() * 1000, title: 'Something', done: false},
      ],
    },
    {
      id: Math.random() * 1000,
      tag: 'Progressing',
      task: 'User flow mapping',
      desc: 'Raisen',
      subtasks: [
        {id: Math.random() * 1000, title: 'Something', done: false},
        {id: Math.random() * 1000, title: 'Something', done: true},
        {id: Math.random() * 1000, title: 'Something', done: true},
        {id: Math.random() * 1000, title: 'Something', done: false},
      ],
      progress() {
        return (
          (100 * this.subtasks.filter(sub => sub.done).length) /
          this.subtasks.length
        );
      },
    },
    {
      id: Math.random() * 1000,
      tag: 'Todo',
      task: 'Client flow mapping',
      desc: 'Raisen',
      subtasks: [
        {id: Math.random() * 1000, title: 'Something', done: false},
        {id: Math.random() * 1000, title: 'Something', done: true},
        {id: Math.random() * 1000, title: 'Something', done: true},
        {id: Math.random() * 1000, title: 'Something', done: false},
      ],
    },
    {
      id: Math.random() * 1000,
      tag: 'Todo',
      task: 'User flow mapping',
      desc: 'Raisen',
      subtasks: [
        {id: Math.random() * 1000, title: 'Something', done: false},
        {id: Math.random() * 1000, title: 'Something', done: true},
        {id: Math.random() * 1000, title: 'Something', done: true},
        {id: Math.random() * 1000, title: 'Something', done: false},
      ],
    },
    {
      id: Math.random() * 1000,
      tag: 'Todo',
      task: 'User flow mapping',
      desc: 'Raisen',
      subtasks: [
        {id: Math.random() * 1000, title: 'Something', done: false},
        {id: Math.random() * 1000, title: 'Something', done: true},
        {id: Math.random() * 1000, title: 'Something', done: true},
        {id: Math.random() * 1000, title: 'Something', done: false},
      ],
    },
    {
      id: Math.random() * 1000,
      tag: 'Todo',
      task: 'User flow mapping',
      desc: 'Raisen',
      subtasks: [
        {id: Math.random() * 1000, title: 'Something', done: false},
        {id: Math.random() * 1000, title: 'Something', done: true},
        {id: Math.random() * 1000, title: 'Something', done: true},
        {id: Math.random() * 1000, title: 'Something', done: false},
      ],
      progress() {
        return (
          (100 * this.subtasks.filter(sub => sub.done).length) /
          this.subtasks.length
        );
      },
    },

    {
      id: Math.random() * 1000,
      tag: 'Todo',
      task: 'Server flow mapping',
      desc: 'Raisen',
      subtasks: [
        {id: Math.random() * 1000, title: 'Something', done: false},
        {id: Math.random() * 1000, title: 'Something', done: true},
        {id: Math.random() * 1000, title: 'Something', done: true},
        {id: Math.random() * 1000, title: 'Something', done: false},
      ],
    },
    {
      id: Math.random() * 1000,
      tag: 'Completed',
      task: 'User flow mapping',
      desc: 'Raisen',
      subtasks: [
        {id: Math.random() * 1000, title: 'Something', done: false},
        {id: Math.random() * 1000, title: 'Something', done: true},
        {id: Math.random() * 1000, title: 'Something', done: true},
        {id: Math.random() * 1000, title: 'Something', done: false},
      ],
    },
    {
      id: Math.random() * 1000,
      tag: 'Completed',
      task: 'User flow mapping',
      desc: 'Raisen',
      subtasks: [
        {id: Math.random() * 1000, title: 'Something', done: false},
        {id: Math.random() * 1000, title: 'Something', done: true},
        {id: Math.random() * 1000, title: 'Something', done: true},
        {id: Math.random() * 1000, title: 'Something', done: false},
      ],
    },
    {
      id: Math.random() * 1000,
      tag: 'Completed',
      task: 'User flow mapping',
      desc: 'Raisen',
      subtasks: [
        {id: Math.random() * 1000, title: 'Something', done: false},
        {id: Math.random() * 1000, title: 'Something', done: true},
        {id: Math.random() * 1000, title: 'Something', done: true},
        {id: Math.random() * 1000, title: 'Something', done: false},
      ],
      progress() {
        return (
          (100 * this.subtasks.filter(sub => sub.done).length) /
          this.subtasks.length
        );
      },
    },
  ],
};

const taskSLice = createSlice({
  name: 'tasks',
  initialState,
  reducers: {
    addTask: (state, {payload}) => {
      payload.subtasks.forEach(element => {
        element.id = Math.floor(Math.random(1000));
      });
      state.allTasks.push(payload);
    },
    removeTask: (state, {payload}) => {
      state.allTasks = state.addTask.filter(task => task.id != payload.id);
    },
    changeStatusOfSubtask: (state, {payload}) => {
      const index = state.allTasks.findIndex(task => task.id == payload.taskId);
      console.log(payload);
      const subtaskIndex = state.allTasks[index].subtasks.findIndex(
        subtask => subtask.id == payload.subtaskId,
      );
      state.allTasks[index].subtasks[subtaskIndex].done = payload.value;
    },
    setCachedTask: (state, {payload}) => (state.cachedTask = payload),
  },
});

export const {addTask, removeTask, changeStatusOfSubtask, setCachedTask} =
  taskSLice.actions;
export default taskSLice.reducer;
